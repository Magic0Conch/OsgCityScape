#include "Editor/Core/Application.h"
#include "osgDB/ReadFile"



int main(){
    CSEditor::Core::Application app;
    app.run();
    return 0;
}