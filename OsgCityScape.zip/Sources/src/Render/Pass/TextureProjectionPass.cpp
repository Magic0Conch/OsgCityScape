#include <osg/Camera>
#include <osg/Program>
#include "GL/glcorearb.h"
#include "Resources/ResourceManagement/ConfigManager.h"
#include "Render/Pass/TextureProjectionPass.h"
#include "Editor/Core/RuntimeContext.h"
#include "Windowing/Window.h"
#include "Resources/Loaders/ShaderLoader.h"
#include <osg/CullFace>
#include "osg/Image"
#include "osg/StateAttribute"
#include "osg/ref_ptr"

using namespace CSEditor::Render;
using namespace CSEditor;
void createTextureProjectionShader(osg::StateSet* ss) {
    const std::string& vertPath = (Core::g_runtimeContext.configManager->getShaderFolder() / "common/TextureProjection.vert").string();
    const std::string& fragPath = (Core::g_runtimeContext.configManager->getShaderFolder() / "common/TextureProjection.frag").string();
    osg::ref_ptr<osg::Program> program = Resources::ShaderLoader::create(vertPath, fragPath);   
    
    ss->setAttributeAndModes(program.get(), osg::StateAttribute::ON);
}

TextureProjectionPass::TextureProjectionPass(osg::ref_ptr<osg::Camera> camera):m_camera(camera) {
    m_camera->setClearMask(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    m_camera->setRenderTargetImplementation(osg::Camera::FRAME_BUFFER_OBJECT);
    m_camera->setName("RenderColor");

    _texture = new osg::Texture2D();
    _texture->setWrap(osg::Texture2D::WrapParameter::WRAP_T,osg::Texture2D::WrapMode::REPEAT);
    _texture->setWrap(osg::Texture2D::WrapParameter::WRAP_S,osg::Texture2D::WrapMode::REPEAT);
    _texture->setSourceFormat(GL_RGBA);
    _texture->setInternalFormat(GL_RGBA8);
    _texture->setSourceType(GL_FLOAT);

    _depthStencilTexture = new osg::Texture2D();
    _depthStencilTexture->setWrap(osg::Texture2D::WrapParameter::WRAP_T,osg::Texture2D::WrapMode::REPEAT);
    _depthStencilTexture->setWrap(osg::Texture2D::WrapParameter::WRAP_S,osg::Texture2D::WrapMode::REPEAT);
    _depthStencilTexture->setSourceFormat(GL_DEPTH_STENCIL);
    _depthStencilTexture->setInternalFormat(GL_DEPTH24_STENCIL8);
    _depthStencilTexture->setSourceType(GL_UNSIGNED_INT_24_8);    

    auto stateSet = m_camera->getOrCreateStateSet();
    createTextureProjectionShader(stateSet);
    stateSet->addUniform(new osg::Uniform("depthMap", 1));
    stateSet->addUniform(new osg::Uniform("colorMap", 2));
    stateSet->addUniform(new osg::Uniform("mainTexture", 0));
    stateSet->addUniform(new osg::Uniform("mapSize", 0));
    m_lightSpaceMatrixUniform = new osg::Uniform(osg::Uniform::FLOAT_MAT4, "lightSpaceMatrix", 16);
    stateSet->addUniform(m_lightSpaceMatrixUniform);
    stateSet->addUniform(projectionUniform);

    m_enableProjectionUniform = new osg::Uniform(osg::Uniform::BOOL, "_EnableProjection", 16);
    stateSet->addUniform(m_enableProjectionUniform);

    // m_camera->setNodeMask(0x1);
    m_camera->setCullingMode(m_camera->getCullingMode() & ~osg::CullSettings::SMALL_FEATURE_CULLING);
    m_camera->attach(osg::Camera::COLOR_BUFFER0, _texture);
    
    m_camera->attach(osg::Camera::PACKED_DEPTH_STENCIL_BUFFER, _depthStencilTexture);
    Core::g_runtimeContext.windowSystem->setScreenTexture(_texture);
    auto cullFace = new osg::CullFace;
    cullFace->setMode(osg::CullFace::BACK);
    stateSet->setAttributeAndModes(cullFace, osg::StateAttribute::ON);
}


void TextureProjectionPass::setTextureArray(osg::ref_ptr<osg::Texture2DArray> depthMapArray, std::vector<osg::ref_ptr<osg::Texture2D>> colorTexVec, std::vector<osg::Matrixd>& projectionMatrixVec) {
    if(depthMapArray == nullptr || colorTexVec.empty() || colorTexVec[0] == nullptr || projectionMatrixVec.empty()) {
        return;
    }
    if (!m_colorMap) {
        m_colorMap = new osg::Texture2DArray;
        m_colorMap->setInternalFormat(GL_RGBA);
    }
    int cnt = colorTexVec.size();
    m_colorMap->setTextureSize(colorTexVec[0]->getTextureWidth(), colorTexVec[0]->getTextureHeight(), cnt);
    m_colorMap->setInternalFormat(colorTexVec[0]->getInternalFormat());
    // m_colorMap->setInternalFormatMode(osg::Texture2D::USE_S3TC_DXT1_COMPRESSION);
    // m_colorMap->setUnRefImageDataAfterApply(true);
    for (int i = 0; i < cnt; i++) {
        m_colorMap->setImage(i, colorTexVec[i]->getImage());
    }
    auto stateSet = m_camera->getOrCreateStateSet();
    stateSet->setTextureAttributeAndModes(1, depthMapArray, osg::StateAttribute::ON);
    stateSet->setTextureAttributeAndModes(2, m_colorMap, osg::StateAttribute::ON);
    stateSet->getUniform("mapSize")->set(cnt);
    for (int i = 0; i < cnt; ++i) {
        auto& projectionMatrix = projectionMatrixVec[i];
        m_lightSpaceMatrixUniform->setElement(i, projectionMatrix);
        m_enableProjectionUniform->setElement(i, true);
    }
}


void TextureProjectionPass::setTexture(int index ,osg::ref_ptr<osg::Texture2D> tex){
    auto stateSet = m_camera->getOrCreateStateSet();
    osg::Image* image = tex->getImage();
    m_colorMap->setImage(index, image);
    stateSet->setTextureAttributeAndModes(2, m_colorMap, osg::StateAttribute::ON);
}

void TextureProjectionPass::setTexture(int index ,osg::ref_ptr<osg::Image> img){
    auto stateSet = m_camera->getOrCreateStateSet();
    m_colorMap->setImage(index, img);
    stateSet->setTextureAttributeAndModes(2, m_colorMap, osg::StateAttribute::ON);
}

osg::ref_ptr<osg::Texture2D> TextureProjectionPass::getColorTexture() {
    return _texture; 
}
osg::ref_ptr<osg::Texture2D> TextureProjectionPass::getDepthStencilTexture() { 
    return _depthStencilTexture; 
}

void TextureProjectionPass::setProjectionMatrix(const osg::Matrixd& projectionMatrix) {
    projectionUniform->set(projectionMatrix);
}

void TextureProjectionPass::setLightSpaceMatrixUniform(int index,osg::Matrixd& lightSpaceMatrix){
    auto ss = m_camera->getOrCreateStateSet();        
    auto projectionMatrixUniform = ss->getUniform("lightSpaceMatrix");
    if (!projectionMatrixUniform) {
        // 创建并添加 uniform 如果不存在
        projectionMatrixUniform = new osg::Uniform(osg::Uniform::FLOAT_MAT4, "lightSpaceMatrix");
        ss->addUniform(projectionMatrixUniform);
    }
    projectionMatrixUniform->setElement(index, lightSpaceMatrix);
}

void TextureProjectionPass::setProjectionEnabled(int index, bool enable){
    m_enableProjectionUniform->setElement(index, enable);
}