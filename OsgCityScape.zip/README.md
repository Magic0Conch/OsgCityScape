# OsgCityScape
Implementing some effects based on openscenegraph.

## 3rd lib
1. openscenegraph(3.6.4 opengl3.x)
2. dear imgui(1.85)

## How to start
1. Install the 3rd dll and shader file to the bin dir.
2. Build all(debug mode) using cmake tools in vscode.


